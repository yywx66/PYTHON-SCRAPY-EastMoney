
import requests
from bs4 import BeautifulSoup

#molimoli
#获得股票的股票号和名字，得到文本

url = 'http://quote.eastmoney.com/stock_list.html'
html=requests.get(url)
soup=BeautifulSoup(html.content,'lxml')
stocks_in = soup.find_all("li")

for stock_in in stocks_in:
    print(stock_in.get_text())













