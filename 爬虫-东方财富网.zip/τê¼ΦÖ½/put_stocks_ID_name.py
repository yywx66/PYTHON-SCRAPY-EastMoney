#molimoli
#读取txt文档的信息并放在已存在的数据库"stock_lists"中

import sys
import os
import re
import pymysql

#建立连接，检测是否连接上
db = pymysql.connections.Connection(      #根据个人的数据库信息来改
    host='127.0.0.1',
    port=3306,
    user='root',
    password='miyinan2000',
    charset='utf8'
)
print('connected')

#建表
cursor = db.cursor()
cursor.execute("USE stock_lists")
cursor = db.cursor()
cursor.execute("DROP TABLE IF EXISTS stocks_informations")
sql = """
       CREATE TABLE stocks_informations
       (
       No INT,
       STOCKS_ID varchar(255),
       STICKS_NAME varchar(255),
       SUPPORTING INT
       )"""

cursor.execute(sql)

txt = open('./stocks_in.txt')  #这里写的是相对路径

#把股票信息插入表中
No = 0
for line in txt.readlines():
    line = re.split('\(|\)', line)
    sql = "INSERT INTO stocks_informations VALUES (%d,'%s','%s',0)"
    cursor.execute(sql % (No, line[0], line[1]))
    No=No+1        #给每支股票一个序号，方便以后查找

db.commit()#记得提交数据
cursor.close()
print('finished!')
