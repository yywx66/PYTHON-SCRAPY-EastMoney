#molimoli
#循环获得股票有用的信息并写入数据库

import re
import requests
import json
import pymysql

# 连接到数据库
db = pymysql.connections.Connection(
    host='127.0.0.1',
    port=3306,
    user='root',
    password='miyinan2000',
    charset='utf8')
global id


# 从数据库中获取股票id和name，返回的是二维数组，[0]是id，[1]是name
def get_stock_id_name(id):
    cursor = db.cursor()
    cursor.execute("USE stock_lists")  #由于我每次都close，还是把获取游标写在里面
    sql = """
    SELECT Stock_ID,Stock_name 
    FROM stock_lists.stocks_information 
    WHERE ID = %s 
    """
    cursor.execute(sql, id)
    re1 = cursor.fetchall()
    cursor.close()
    id = re1[0][0]
    name = re1[0][1]
    name2=re.sub("\*","o",name)
    information = [id, name2]
    return information

#修改股票是否支持融资融券的参数supporting
def write_supporting(tf,id):
    cursor=db.cursor()
    cursor.execute("USE stock_lists")
    cursor.execute("SET SQL_SAFE_UPDATES = 0") #影响权限，不置零可能导致数据无法写入
    sql = "UPDATE stock_lists.stocks_information SET supporting=%d WHERE ID=%d"
    cursor.execute(sql%(tf,id))
    db.commit()
    cursor.close()
    return

#给出股票的名字和id，在数据库中创建表格
def establish_table(sto_id, sto_name):  # 输入两个字符串
    table_name = sto_id + sto_name
    cursor = db.cursor()
    cursor.execute("USE stock_lists")
    cursor.execute("DROP TABLE IF EXISTS %s" % (table_name))
    sql = """
       CREATE TABLE whatever
       (
       date DATE,
       HolderNum VARCHAR(50),
       ClosePrice VARCHAR(50) 
       )"""
    cursor.execute(sql)
    cursor.execute("RENAME TABLE whatever TO %s" % (table_name))
    db.commit()
    cursor.close()
    return table_name

# 根据页面和股票号生成需要的request链接，i是整形，scode是字符串
def mix_url(i, scode):
    p = str(i)
    a = 'http://datacenter.eastmoney.com/api/data/get?type=RPTA_WEB_RZRQ_GGMX&sty=ALL&source=WEB&p='
    b = '&ps=50&st=date&sr=-1&filter=(scode=%22'
    c = '%22)'
    url = a + p + b + scode + c  #只有字符串才可以用这个语句，所以要先把整形变为字符串
    return url

#从url request中获得需要的信息列表
def get_data_list(id, url):  # url就是刚刚生成的连接
    json_ = requests.get(url).content
    html = json.loads(json_)
    result1 = html['result']
    if result1:
        result2 = result1['data']
        return result2
    else:
        print('not supporting:', id)
        return 0

#删表的语句，给出表的名字就可以删掉（非循环）
def delete_table(table_name):
    cursor = db.cursor()
    cursor.execute("USE stock_lists")
    cursor = db.cursor()
    cursor.execute("DROP TABLE IF EXISTS %s" % (table_name))
    db.commit()
    return

#从全部信息的大列表中摘出需要的个别信息，得到一个新的更简洁的列表
def get_needed_data(data_num, list):  # 给出日期编号（信息的编号）和该页面信息列表得到筛选出的当天的信息,返回列表
    data = list[data_num]
    closeprize = float(data['SPJ'])
    date_ = data['DATE']
    date1 = date_[0:10]
    holden = data['RZYE']
    data_list = [date1, holden, closeprize]
    return data_list

#把信息写入数据库（非循环）
def insert_needed_data(list, table_name):
    cursor = db.cursor()
    cursor.execute("USE stock_lists")
    sql = "INSERT INTO %s VALUES ('%s','%s','%s')"
    cursor.execute(sql % (table_name, list[0], list[1], list[2]))
    db.commit()
    cursor.close()

#把一支股票的全部信息写入建好的表中
def insert_data(id, stock_id, table_name):
    for page in range(1, 8):  # 插入每一只股票每日所需信息
        url = mix_url(page, stock_id)
        print(url)
        list = get_data_list(id, url)
        if list == 0:
            if page==1:
                write_supporting(0, id)
                id = id + 1
                delete_table(table_name)
                break
            id=id+1
            break

        for data_num in range(0, 49):
            if data_num >= len(list):
                print(len(list),data_num)
                break
            data_list = get_needed_data(data_num, list)
            insert_needed_data(data_list, table_name)
        write_supporting(1, id)


#主函数，这个range需要自己去数据库中的股票信息表（stocks_information）看有多少个股
for id in range(436, 500):
    stock = get_stock_id_name(id)
    table_name = establish_table(stock[0], stock[1])
    insert_data(id, stock[0], table_name)

